namespace LE7_Umali;

internal sealed record Country(string Name, string Continent, string Capital, long Population, long Area, string Currency, string Code)
{
    public string PopulationText => Population.ToString("N0") + " people";
    public string AreaText => Area.ToString("N0") + " km²";
    public string Flag => string.Concat(Code.ToUpperInvariant().Select(c => char.ConvertFromUtf32(0x1F1E6 + c - 'A')));
}

internal static class CountryData
{
    public static readonly string[] Continents = ["Asia", "Africa", "North America", "South America", "Antarctica", "Europe", "Australia"];
    public static readonly Country[] All =
    [
        new("Afghanistan","Asia","Kabul",42239854,652230,"Afghan afghani","AF"), new("Bangladesh","Asia","Dhaka",172954319,148460,"Bangladeshi taka","BD"), new("China","Asia","Beijing",1410710000,9596961,"Renminbi (yuan)","CN"), new("India","Asia","New Delhi",1428627663,3287263,"Indian rupee","IN"), new("Indonesia","Asia","Jakarta",277534122,1904569,"Indonesian rupiah","ID"), new("Japan","Asia","Tokyo",124516650,377975,"Japanese yen","JP"), new("Philippines","Asia","Manila",114163719,300000,"Philippine peso","PH"), new("South Korea","Asia","Seoul",51784059,100210,"South Korean won","KR"), new("Thailand","Asia","Bangkok",71801279,513120,"Thai baht","TH"), new("Vietnam","Asia","Hanoi",98858950,331212,"Vietnamese đồng","VN"),
        new("Algeria","Africa","Algiers",45606480,2381741,"Algerian dinar","DZ"), new("Egypt","Africa","Cairo",112716598,1002450,"Egyptian pound","EG"), new("Ethiopia","Africa","Addis Ababa",126527060,1104300,"Ethiopian birr","ET"), new("Kenya","Africa","Nairobi",55100586,580367,"Kenyan shilling","KE"), new("Morocco","Africa","Rabat",37840044,446550,"Moroccan dirham","MA"), new("Nigeria","Africa","Abuja",223804632,923768,"Nigerian naira","NG"), new("South Africa","Africa","Pretoria",60414495,1221037,"South African rand","ZA"), new("Tanzania","Africa","Dodoma",67438106,947303,"Tanzanian shilling","TZ"),
        new("Canada","North America","Ottawa",40097761,9984670,"Canadian dollar","CA"), new("Costa Rica","North America","San José",5212173,51100,"Costa Rican colón","CR"), new("Cuba","North America","Havana",11194449,109884,"Cuban peso","CU"), new("Mexico","North America","Mexico City",128455567,1964375,"Mexican peso","MX"), new("United States","North America","Washington, D.C.",334914895,9833517,"United States dollar","US"),
        new("Argentina","South America","Buenos Aires",45773884,2780400,"Argentine peso","AR"), new("Brazil","South America","Brasília",216422446,8515767,"Brazilian real","BR"), new("Chile","South America","Santiago",19629590,756102,"Chilean peso","CL"), new("Colombia","South America","Bogotá",52085168,1141748,"Colombian peso","CO"), new("Peru","South America","Lima",34352719,1285216,"Peruvian sol","PE"), new("Venezuela","South America","Caracas",28838499,916445,"Venezuelan bolívar","VE"),
        new("Antarctica","Antarctica","No capital",0,14000000,"No official currency","AQ"),
        new("France","Europe","Paris",68170228,551695,"Euro","FR"), new("Germany","Europe","Berlin",84552242,357022,"Euro","DE"), new("Italy","Europe","Rome",58870762,301340,"Euro","IT"), new("Netherlands","Europe","Amsterdam",17811291,41543,"Euro","NL"), new("Spain","Europe","Madrid",48373336,505990,"Euro","ES"), new("Ukraine","Europe","Kyiv",36744634,603500,"Ukrainian hryvnia","UA"), new("United Kingdom","Europe","London",68350000,243610,"Pound sterling","GB"),
        new("Australia","Australia","Canberra",26439111,7692024,"Australian dollar","AU"), new("Fiji","Australia","Suva",936375,18274,"Fijian dollar","FJ"), new("New Zealand","Australia","Wellington",5228100,268838,"New Zealand dollar","NZ"), new("Papua New Guinea","Australia","Port Moresby",10329931,462840,"Papua New Guinean kina","PG")
    ];
}
