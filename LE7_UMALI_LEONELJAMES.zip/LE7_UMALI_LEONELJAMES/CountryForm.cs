namespace LE7_Umali;

internal sealed class CountryForm : Form
{
    private readonly ComboBox continentBox = new();
    private readonly ComboBox countryBox = new();
    private readonly PictureBox flag = new();
    private readonly Label title = new();
    private readonly Label capital = new();
    private readonly Label population = new();
    private readonly Label area = new();
    private readonly Label currency = new();

    public CountryForm(string initialContinent)
    {
        Text = "Countries | World Atlas";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(960, 680);
        Size = new Size(1180, 790);
        BackColor = Color.FromArgb(241, 247, 250);
        Font = new Font("Segoe UI", 10);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, ColumnCount = 1, Padding = new Padding(0), BackColor = Color.Transparent };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 65));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(root);

        var selectors = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, Padding = new Padding(18, 15, 10, 5), BackColor = Color.White };
        selectors.Controls.Add(new Label { Text = "Continent:", AutoSize = true, Margin = new Padding(3, 7, 8, 0), ForeColor = Color.FromArgb(55, 68, 83) });
        continentBox.DropDownStyle = ComboBoxStyle.DropDownList;
        continentBox.Width = 190;
        continentBox.Margin = new Padding(0, 2, 25, 0);
        continentBox.Items.AddRange(CountryData.Continents.Cast<object>().ToArray());
        selectors.Controls.Add(continentBox);
        selectors.Controls.Add(new Label { Text = "Country:", AutoSize = true, Margin = new Padding(0, 7, 8, 0), ForeColor = Color.FromArgb(55, 68, 83) });
        countryBox.DropDownStyle = ComboBoxStyle.DropDownList;
        countryBox.Width = 245;
        countryBox.Margin = new Padding(0, 2, 0, 0);
        selectors.Controls.Add(countryBox);
        root.Controls.Add(selectors, 0, 0);

        var canvas = new Panel { Dock = DockStyle.Fill, BackgroundImageLayout = ImageLayout.Zoom, BackColor = Color.FromArgb(228, 246, 250) };
        var imagePath = Path.Combine(AppContext.BaseDirectory, "world-map.png");
        if (File.Exists(imagePath)) canvas.BackgroundImage = Image.FromFile(imagePath);
        root.Controls.Add(canvas, 0, 1);

        var card = new TableLayoutPanel
        {
            Size = new Size(700, 575), Anchor = AnchorStyles.None, BackColor = Color.White,
            Padding = new Padding(24), ColumnCount = 2, RowCount = 4,
            CellBorderStyle = TableLayoutPanelCellBorderStyle.None
        };
        card.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        card.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        card.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        card.RowStyles.Add(new RowStyle(SizeType.Percent, 54));
        card.RowStyles.Add(new RowStyle(SizeType.Percent, 23));
        card.RowStyles.Add(new RowStyle(SizeType.Percent, 23));
        canvas.Controls.Add(card);
        canvas.Resize += (_, _) => card.Location = new Point((canvas.ClientSize.Width - card.Width) / 2, (canvas.ClientSize.Height - card.Height) / 2);
        Shown += (_, _) => card.Location = new Point((canvas.ClientSize.Width - card.Width) / 2, (canvas.ClientSize.Height - card.Height) / 2);

        title.Text = "COUNTRY PROFILE";
        title.Dock = DockStyle.Fill;
        title.Font = new Font("Segoe UI", 15, FontStyle.Bold);
        title.ForeColor = Color.FromArgb(34, 59, 75);
        title.TextAlign = ContentAlignment.MiddleCenter;
        card.Controls.Add(title, 0, 0);
        card.SetColumnSpan(title, 2);

        flag.Dock = DockStyle.Fill;
        flag.SizeMode = PictureBoxSizeMode.Zoom;
        flag.Margin = new Padding(4, 4, 4, 16);
        card.Controls.Add(flag, 0, 1);
        card.SetColumnSpan(flag, 2);

        AddFact(card, "CAPITAL", capital, 2, 0);
        AddFact(card, "POPULATION", population, 2, 1);
        AddFact(card, "AREA", area, 3, 0);
        AddFact(card, "CURRENCY", currency, 3, 1);

        continentBox.SelectedIndexChanged += (_, _) => LoadCountries();
        countryBox.SelectedIndexChanged += (_, _) => ShowCountry(countryBox.SelectedItem as Country);
        var initialIndex = Array.IndexOf(CountryData.Continents, initialContinent);
        continentBox.SelectedIndex = initialIndex >= 0 ? initialIndex : 0;
    }

    private static void AddFact(TableLayoutPanel card, string caption, Label value, int row, int column)
    {
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(10, 5, 10, 2) };
        panel.Controls.Add(new Label { Text = caption, Dock = DockStyle.Top, Height = 21, Font = new Font("Segoe UI", 8, FontStyle.Bold), ForeColor = Color.FromArgb(99, 117, 132) });
        value.Dock = DockStyle.Fill;
        value.Font = new Font("Segoe UI", 13, FontStyle.Bold);
        value.ForeColor = Color.FromArgb(32, 47, 63);
        value.TextAlign = ContentAlignment.MiddleLeft;
        panel.Controls.Add(value);
        card.Controls.Add(panel, column, row);
    }

    private void LoadCountries()
    {
        if (continentBox.SelectedItem is not string continent) return;
        var countries = CountryData.All.Where(c => c.Continent == continent).OrderBy(c => c.Name).ToArray();
        countryBox.BeginUpdate();
        countryBox.Items.Clear();
        countryBox.Items.AddRange(countries.Cast<object>().ToArray());
        countryBox.DisplayMember = nameof(Country.Name);
        countryBox.EndUpdate();
        var initialName = continent == "Asia" ? "Philippines" : null;
        countryBox.SelectedIndex = initialName is null ? (countries.Length > 0 ? 0 : -1) : Array.FindIndex(countries, c => c.Name == initialName);
        if (countryBox.SelectedIndex < 0 && countries.Length > 0) countryBox.SelectedIndex = 0;
    }

    private void ShowCountry(Country? country)
    {
        flag.Image?.Dispose();
        if (country is null)
        {
            flag.Image = null;
            title.Text = "COUNTRY PROFILE";
            capital.Text = population.Text = area.Text = currency.Text = "—";
            return;
        }
        title.Text = country.Name;
        flag.Image = FlagArt.Create(country.Code);
        capital.Text = country.Capital;
        population.Text = country.PopulationText;
        area.Text = country.AreaText;
        currency.Text = country.Currency;
    }

}
