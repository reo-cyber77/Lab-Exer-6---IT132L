namespace LE7_Umali;

internal static class FlagArt
{
    public static Bitmap Create(string code)
    {
        const int w = 840, h = 500;
        var bmp = new Bitmap(w, h);
        using var g = Graphics.FromImage(bmp);
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        g.Clear(Color.White);
        var red = Color.FromArgb(206, 17, 38);
        var blue = Color.FromArgb(0, 56, 168);

        switch (code)
        {
            case "PH":
                g.Clear(blue);
                g.FillRectangle(new SolidBrush(red), 0, h / 2, w, h / 2);
                g.FillPolygon(Brushes.White, [new Point(0, 0), new Point(360, h / 2), new Point(0, h)]);
                DrawSun(g, 128, 250, 44, Color.FromArgb(252, 209, 22));
                DrawStar(g, 39, 38, 19, Color.FromArgb(252, 209, 22));
                DrawStar(g, 39, 462, 19, Color.FromArgb(252, 209, 22));
                DrawStar(g, 325, 250, 19, Color.FromArgb(252, 209, 22));
                break;
            case "JP":
                g.Clear(Color.White);
                using (var b = new SolidBrush(Color.FromArgb(188, 0, 45))) g.FillEllipse(b, 315, 115, 210, 210);
                break;
            case "FR": Vertical(g, Color.FromArgb(0, 85, 164), Color.White, Color.FromArgb(239, 65, 53)); break;
            case "IT": Vertical(g, Color.FromArgb(0, 140, 69), Color.White, Color.FromArgb(205, 33, 42)); break;
            case "DE": Horizontal(g, Color.Black, Color.FromArgb(221, 0, 0), Color.FromArgb(255, 206, 0)); break;
            case "RU": Horizontal(g, Color.White, Color.FromArgb(0, 57, 166), Color.FromArgb(213, 43, 30)); break;
            case "NL": Horizontal(g, Color.FromArgb(174, 28, 40), Color.White, Color.FromArgb(33, 70, 139)); break;
            case "IE": Vertical(g, Color.FromArgb(22, 155, 98), Color.White, Color.FromArgb(255, 136, 62)); break;
            case "CA":
                g.Clear(Color.White);
                using (var b = new SolidBrush(Color.FromArgb(213, 43, 30))) { g.FillRectangle(b, 0, 0, 205, h); g.FillRectangle(b, 635, 0, 205, h); }
                DrawMaple(g, 420, 250, red);
                break;
            case "BR":
                g.Clear(Color.FromArgb(0, 156, 59));
                g.FillPolygon(new SolidBrush(Color.FromArgb(255, 223, 0)), [new Point(420, 52), new Point(777, 250), new Point(420, 448), new Point(63, 250)]);
                g.FillEllipse(new SolidBrush(Color.FromArgb(0, 39, 118)), 300, 130, 240, 240);
                break;
            case "CN":
                g.Clear(Color.FromArgb(222, 41, 16));
                DrawStar(g, 148, 125, 46, Color.FromArgb(255, 222, 0));
                DrawStar(g, 242, 75, 16, Color.FromArgb(255, 222, 0)); DrawStar(g, 275, 125, 16, Color.FromArgb(255, 222, 0));
                DrawStar(g, 275, 183, 16, Color.FromArgb(255, 222, 0)); DrawStar(g, 242, 230, 16, Color.FromArgb(255, 222, 0));
                break;
            case "US":
                for (int i = 0; i < 13; i++) { using var b = new SolidBrush(i % 2 == 0 ? Color.FromArgb(178, 34, 52) : Color.White); g.FillRectangle(b, 0, i * (h / 13), w, h / 13 + 1); }
                g.FillRectangle(new SolidBrush(Color.FromArgb(60, 59, 110)), 0, 0, 390, 270);
                for (int row = 0; row < 5; row++) for (int col = 0; col < 6; col++) g.FillEllipse(Brushes.White, 22 + col * 58, 22 + row * 48, 13, 13);
                break;
            case "ZA":
                Horizontal(g, Color.FromArgb(222, 56, 49), Color.White, Color.FromArgb(0, 35, 149));
                g.FillPolygon(new SolidBrush(Color.FromArgb(0, 122, 77)), [new(0, 0), new(380, 250), new(0, 500)]);
                g.FillPolygon(Brushes.Yellow, [new(0, 56), new(295, 250), new(0, 444), new(0, 381), new(205, 250), new(0, 119)]);
                g.FillPolygon(Brushes.Black, [new(0, 104), new(220, 250), new(0, 396)]);
                break;
            case "AU": case "NZ":
                g.Clear(Color.FromArgb(0, 35, 149));
                DrawUnionJack(g, 0, 0, 350, 205);
                for (int i = 0; i < 6; i++) DrawStar(g, 470 + (i % 2) * 170, 95 + (i / 2) * 116, 17, Color.White);
                break;
            case "IN":
                Horizontal(g, Color.FromArgb(255, 153, 51), Color.White, Color.FromArgb(19, 136, 8));
                using (var p = new Pen(Color.FromArgb(0, 0, 128), 9)) g.DrawEllipse(p, 363, 193, 114, 114);
                break;
            default:
                var hues = new[] { Color.FromArgb(0, 82, 165), Color.White, Color.FromArgb(220, 40, 50) };
                int seed = Math.Abs(code.GetHashCode());
                Horizontal(g, hues[seed % 3], hues[(seed / 3 + 1) % 3], hues[(seed / 7 + 2) % 3]);
                break;
        }
        using var outline = new Pen(Color.FromArgb(225, 226, 229), 2);
        g.DrawRectangle(outline, 1, 1, w - 3, h - 3);
        return bmp;
    }

    private static void Vertical(Graphics g, Color a, Color b, Color c)
    {
        using var ba = new SolidBrush(a); using var bb = new SolidBrush(b); using var bc = new SolidBrush(c);
        g.FillRectangle(ba, 0, 0, 280, 500); g.FillRectangle(bb, 280, 0, 280, 500); g.FillRectangle(bc, 560, 0, 280, 500);
    }

    private static void Horizontal(Graphics g, Color a, Color b, Color c)
    {
        using var ba = new SolidBrush(a); using var bb = new SolidBrush(b); using var bc = new SolidBrush(c);
        g.FillRectangle(ba, 0, 0, 840, 167); g.FillRectangle(bb, 0, 167, 840, 166); g.FillRectangle(bc, 0, 333, 840, 167);
    }

    private static void DrawSun(Graphics g, int x, int y, int r, Color color)
    {
        using var b = new SolidBrush(color); using var p = new Pen(color, 8);
        for (int i = 0; i < 8; i++) { double a = Math.PI * i / 4; g.DrawLine(p, x + (float)Math.Cos(a) * (r + 3), y + (float)Math.Sin(a) * (r + 3), x + (float)Math.Cos(a) * (r + 25), y + (float)Math.Sin(a) * (r + 25)); }
        g.FillEllipse(b, x - r, y - r, 2 * r, 2 * r);
    }

    private static void DrawStar(Graphics g, int x, int y, int r, Color color)
    {
        var pts = new PointF[10];
        for (int i = 0; i < 10; i++) { double a = -Math.PI / 2 + Math.PI * i / 5; float rr = i % 2 == 0 ? r : r * .43f; pts[i] = new PointF(x + (float)Math.Cos(a) * rr, y + (float)Math.Sin(a) * rr); }
        using var b = new SolidBrush(color); g.FillPolygon(b, pts);
    }

    private static void DrawUnionJack(Graphics g, int x, int y, int w, int h)
    {
        using var blue = new SolidBrush(Color.FromArgb(0, 36, 125)); using var white = new Pen(Color.White, h * .22f); using var red = new Pen(Color.FromArgb(200, 16, 46), h * .10f);
        g.FillRectangle(blue, x, y, w, h);
        g.DrawLine(white, x, y, x + w, y + h); g.DrawLine(white, x + w, y, x, y + h);
        g.DrawLine(red, x, y, x + w, y + h); g.DrawLine(red, x + w, y, x, y + h);
        g.FillRectangle(Brushes.White, x + w * .40f, y, w * .20f, h); g.FillRectangle(Brushes.White, x, y + h * .36f, w, h * .28f);
        g.FillRectangle(new SolidBrush(Color.FromArgb(200, 16, 46)), x + w * .45f, y, w * .10f, h); g.FillRectangle(new SolidBrush(Color.FromArgb(200, 16, 46)), x, y + h * .41f, w, h * .18f);
    }

    private static void DrawMaple(Graphics g, int x, int y, Color c)
    {
        Point[] points = [new(x, y - 110), new(x + 20, y - 50), new(x + 60, y - 80), new(x + 45, y - 20), new(x + 95, y - 25), new(x + 45, y + 20), new(x + 55, y + 75), new(x + 15, y + 53), new(x + 15, y + 110), new(x - 15, y + 110), new(x - 15, y + 53), new(x - 55, y + 75), new(x - 45, y + 20), new(x - 95, y - 25), new(x - 45, y - 20), new(x - 60, y - 80), new(x - 20, y - 50)];
        using var b = new SolidBrush(c); g.FillPolygon(b, points);
    }
}
