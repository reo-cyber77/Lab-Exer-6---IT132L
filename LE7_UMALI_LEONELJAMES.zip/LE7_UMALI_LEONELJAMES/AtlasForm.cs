namespace LE7_Umali;

internal sealed class AtlasForm : Form
{
    private readonly ToolTip tip = new() { AutoPopDelay = 9000, InitialDelay = 250, ReshowDelay = 150, ShowAlways = true };
    public AtlasForm()
    {
        Text = "Continents | World Atlas";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(940, 700);
        Size = new Size(1240, 830);
        BackColor = Color.White;
        Font = new Font("Segoe UI", 10);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Padding = new Padding(22, 16, 22, 18), BackColor = Color.White };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 93));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(root);

        var header = new Panel { Dock = DockStyle.Fill };
        header.Controls.Add(new Label { Text = "WORLD ATLAS", AutoSize = true, ForeColor = Color.FromArgb(27, 119, 145), Font = new Font("Segoe UI", 9, FontStyle.Bold), Location = new Point(0, 1) });
        header.Controls.Add(new Label { Text = "7 continents, one world to explore", AutoSize = true, ForeColor = Color.FromArgb(32, 47, 63), Font = new Font("Segoe UI", 23, FontStyle.Bold), Location = new Point(0, 22) });
        header.Controls.Add(new Label { Text = "Hover over a continent to learn about it. Click to explore its countries.", AutoSize = true, ForeColor = Color.FromArgb(105, 119, 135), Font = new Font("Segoe UI", 10), Location = new Point(2, 62) });
        root.Controls.Add(header, 0, 0);

        var atlas = new AtlasMapPanel { Dock = DockStyle.Fill, Cursor = Cursors.Hand };
        atlas.ContinentHovered += continent =>
        {
            var description = ContinentDescriptions.GetValueOrDefault(continent, continent);
            tip.Show($"{continent}\n{description}", atlas, atlas.PointToClient(Cursor.Position), 8500);
        };
        atlas.ContinentClicked += continent => new CountryForm(continent).ShowDialog(this);
        root.Controls.Add(atlas, 0, 1);
    }

    internal static readonly Dictionary<string, string> ContinentDescriptions = new()
    {
        ["Asia"] = "Asia includes 50 countries and is the most populated continent. About 60% of Earth's population lives here.",
        ["Africa"] = "Africa comprises 54 countries. It is the hottest continent and home to the Sahara, the world's largest hot desert.",
        ["North America"] = "North America includes 23 countries. The United States has the world's largest national economy.",
        ["South America"] = "South America comprises 12 countries and is home to the Amazon rainforest, the world's largest tropical forest.",
        ["Antarctica"] = "Antarctica is the coldest continent. It has no permanent inhabitants, only researchers at seasonal and year-round stations.",
        ["Europe"] = "Europe comprises 51 countries and is home to the European Union, a major economic and political union.",
        ["Australia"] = "Australia is the least populated continent after Antarctica. Its mainland country shares the continent with Pacific island nations."
    };
}

internal sealed class AtlasMapPanel : Panel
{
    private readonly Image map;
    private string? hover;
    private Rectangle mapRect;
    public event Action<string>? ContinentHovered;
    public event Action<string>? ContinentClicked;

    private static readonly (string Name, float X, float Y, float Radius)[] Regions =
    [
        ("North America", .20f, .34f, .14f), ("South America", .33f, .66f, .105f),
        ("Europe", .49f, .34f, .075f), ("Africa", .52f, .60f, .10f),
        ("Asia", .70f, .38f, .18f), ("Australia", .80f, .76f, .095f), ("Antarctica", .51f, .91f, .08f)
    ];

    public AtlasMapPanel()
    {
        DoubleBuffered = true;
        BackColor = Color.White;
        map = Image.FromFile(Path.Combine(AppContext.BaseDirectory, "world-map.png"));
        MouseMove += OnMapMouseMove;
        MouseLeave += (_, _) => { hover = null; Invalidate(); };
        MouseClick += (_, e) =>
        {
            if (e.Button != MouseButtons.Left || mapRect.Width == 0) return;
            var p = new PointF((e.X - mapRect.X) / (float)mapRect.Width, (e.Y - mapRect.Y) / (float)mapRect.Height);
            var region = Regions.FirstOrDefault(r => Math.Pow(p.X - r.X, 2) + Math.Pow(p.Y - r.Y, 2) < r.Radius * r.Radius);
            if (region.Name is not null) ContinentClicked?.Invoke(region.Name);
        };
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        mapRect = ZoomRect(ClientRectangle, map.Size);
        e.Graphics.DrawImage(map, mapRect);
        using var labelFont = new Font("Segoe UI", Math.Clamp(Width / 68f, 13f, 22f), FontStyle.Bold);
        using var textBrush = new SolidBrush(Color.FromArgb(20, 35, 48));
        using var halo = new Pen(Color.FromArgb(210, Color.White), 4) { LineJoin = System.Drawing.Drawing2D.LineJoin.Round };
        foreach (var r in Regions)
        {
            var x = mapRect.X + mapRect.Width * r.X;
            var y = mapRect.Y + mapRect.Height * r.Y;
            var text = r.Name;
            var size = e.Graphics.MeasureString(text, labelFont);
            var at = new PointF(x - size.Width / 2, y - size.Height / 2);
            using var path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddString(text, labelFont.FontFamily, (int)FontStyle.Bold, e.Graphics.DpiY * labelFont.Size / 72f, at, StringFormat.GenericDefault);
            e.Graphics.DrawPath(halo, path);
            e.Graphics.FillPath(textBrush, path);
            if (hover == r.Name)
            {
                using var pen = new Pen(Color.FromArgb(205, 27, 119, 145), 3);
                var regionRadius = mapRect.Width * r.Radius * .56f;
                e.Graphics.DrawEllipse(pen, x - regionRadius, y - regionRadius, 2 * regionRadius, 2 * regionRadius);
            }
        }
        using var oceanFont = new Font("Segoe UI", Math.Clamp(Width / 100f, 10f, 16f), FontStyle.Italic);
        using var oceanBrush = new SolidBrush(Color.FromArgb(35, 112, 158));
        DrawOcean(e.Graphics, "Arctic Ocean", .49f, .115f, oceanFont, oceanBrush);
        DrawOcean(e.Graphics, "Pacific Ocean", .07f, .48f, oceanFont, oceanBrush);
        DrawOcean(e.Graphics, "Pacific Ocean", .91f, .49f, oceanFont, oceanBrush);
        DrawOcean(e.Graphics, "Atlantic Ocean", .39f, .51f, oceanFont, oceanBrush);
        DrawOcean(e.Graphics, "Indian Ocean", .68f, .66f, oceanFont, oceanBrush);
        DrawOcean(e.Graphics, "Southern Ocean", .51f, .965f, oceanFont, oceanBrush);
    }

    private void OnMapMouseMove(object? sender, MouseEventArgs e)
    {
        if (mapRect.Width == 0) return;
        var p = new PointF((e.X - mapRect.X) / (float)mapRect.Width, (e.Y - mapRect.Y) / (float)mapRect.Height);
        var next = Regions.FirstOrDefault(r => Math.Pow(p.X - r.X, 2) + Math.Pow(p.Y - r.Y, 2) < r.Radius * r.Radius).Name;
        if (next == hover) return;
        hover = next;
        Cursor = hover is null ? Cursors.Default : Cursors.Hand;
        Invalidate();
        if (hover is not null) ContinentHovered?.Invoke(hover);
    }

    private void DrawOcean(Graphics g, string text, float x, float y, Font font, Brush brush)
    {
        var size = g.MeasureString(text, font);
        g.DrawString(text, font, brush, mapRect.X + mapRect.Width * x - size.Width / 2, mapRect.Y + mapRect.Height * y - size.Height / 2);
    }

    private static Rectangle ZoomRect(Rectangle bounds, Size source)
    {
        float scale = Math.Min(bounds.Width / (float)source.Width, bounds.Height / (float)source.Height);
        var w = (int)(source.Width * scale); var h = (int)(source.Height * scale);
        return new Rectangle(bounds.X + (bounds.Width - w) / 2, bounds.Y + (bounds.Height - h) / 2, w, h);
    }
}
