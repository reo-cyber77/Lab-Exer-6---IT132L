using FaceConnect;

var dataDirectory = Path.Combine(AppContext.BaseDirectory, "Data");
var login = new MyLogin(dataDirectory);
var manager = new ManageData(dataDirectory);

Console.WriteLine("====================================");
Console.WriteLine("           FaceConnect");
Console.WriteLine("====================================");

User? currentUser = null;
while (currentUser is null)
{
    Console.Write("Username (X to exit): ");
    var username = Console.ReadLine()?.Trim() ?? string.Empty;
    if (username.Equals("X", StringComparison.OrdinalIgnoreCase))
    {
        Console.WriteLine("Goodbye!");
        return;
    }

    Console.Write("Password: ");
    var password = Console.ReadLine() ?? string.Empty;
    currentUser = login.Authenticate(username, password);
    if (currentUser is null)
        Console.WriteLine("Incorrect username or password. Please try again.\n");
}

Console.WriteLine($"\nWelcome, {currentUser.FirstName} {currentUser.LastName}!");
var running = true;
while (running)
{
    Console.WriteLine("\n----------- Main Menu -----------");
    Console.WriteLine("1. View friends");
    Console.WriteLine("2. Add a friend");
    Console.WriteLine("3. Delete a friend");
    Console.WriteLine("4. Log out");
    Console.Write("Choose an option: ");

    switch (Console.ReadLine()?.Trim())
    {
        case "1":
            var friends = manager.GetFriends(currentUser.Username);
            if (friends.Count == 0)
                Console.WriteLine("You have no friends added yet.");
            else
            {
                Console.WriteLine("Your friends:");
                foreach (var friend in friends)
                    Console.WriteLine($"- {friend}");
            }
            break;
        case "2":
            Console.Write("Enter the username to add: ");
            Console.WriteLine(manager.AddFriend(currentUser.Username, Console.ReadLine()?.Trim() ?? "")
                ? "Friend added."
                : "Could not add friend. Check that the username exists, is not your own, and is not already a friend.");
            break;
        case "3":
            Console.Write("Enter the username to delete: ");
            Console.WriteLine(manager.DeleteFriend(currentUser.Username, Console.ReadLine()?.Trim() ?? "")
                ? "Friend deleted."
                : "That friend was not found in your list.");
            break;
        case "4":
            running = false;
            Console.WriteLine("You have been logged out.");
            break;
        default:
            Console.WriteLine("Please choose 1, 2, 3, or 4.");
            break;
    }
}
