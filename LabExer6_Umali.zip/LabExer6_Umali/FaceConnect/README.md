# FaceConnect

A C# console application for logging in and viewing, adding, and deleting friends. Friend lists and registered account information are stored in plain-text files.

## Run

From this folder, run `dotnet run`.

Sample accounts:

| Username | Password |
| --- | --- |
| reookun | reookun123 |
| Leonel | Leonel123 |
| James | James123 |

## Text-file format

- `userCredentials.txt`: one account per line, with fields `username|password|firstname|lastname|birthdate`.
- `friends/<username>.txt`: one friend username per line. Each listed friend must be registered in `userCredentials.txt`.
- On startup, the app copies its text files to the build output's `Data` folder and saves changes there. Run from the project folder to work with the project text files directly.

For this classroom exercise, passwords are stored as plain text as required by the text-file specification.
