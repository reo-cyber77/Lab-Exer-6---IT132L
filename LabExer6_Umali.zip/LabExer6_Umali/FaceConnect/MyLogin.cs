namespace FaceConnect;

/// <summary>Loads registered users and checks username/password pairs.</summary>
public sealed class MyLogin
{
    private readonly string credentialsPath;

    public MyLogin(string dataDirectory)
    {
        Directory.CreateDirectory(dataDirectory);
        credentialsPath = Path.Combine(dataDirectory, "userCredentials.txt");
        if (!File.Exists(credentialsPath))
            File.WriteAllText(credentialsPath, "# username|password|firstname|lastname|birthdate" + Environment.NewLine);
    }

    // The list of registered usernames is loaded from the text file.
    public List<string> GetUsernames() => ReadUsers().Select(user => user.Username).ToList();

    public User? Authenticate(string username, string password) =>
        ReadUsers().FirstOrDefault(user =>
            user.Username.Equals(username, StringComparison.OrdinalIgnoreCase) &&
            user.Password == password);

    private List<User> ReadUsers()
    {
        var users = new List<User>();
        foreach (var line in File.ReadLines(credentialsPath))
        {
            if (string.IsNullOrWhiteSpace(line) || line.StartsWith('#'))
                continue;

            var fields = line.Split('|');
            if (fields.Length < 5)
                continue;

            users.Add(new User(fields[0].Trim(), fields[1], fields[2].Trim(), fields[3].Trim(), fields[4].Trim()));
        }
        return users;
    }
}
