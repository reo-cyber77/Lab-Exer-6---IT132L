namespace FaceConnect;

public sealed record User(string Username, string Password, string FirstName, string LastName, string Birthdate);
