namespace FaceConnect;

/// <summary>Reads and updates one plain-text friend list per registered username.</summary>
public sealed class ManageData
{
    private readonly string friendsDirectory;
    private readonly HashSet<string> usernames;

    public ManageData(string dataDirectory)
    {
        var credentialsPath = Path.Combine(dataDirectory, "userCredentials.txt");
        friendsDirectory = Path.Combine(dataDirectory, "friends");
        Directory.CreateDirectory(friendsDirectory);

        usernames = File.Exists(credentialsPath)
            ? File.ReadLines(credentialsPath)
                .Where(line => !string.IsNullOrWhiteSpace(line) && !line.StartsWith('#'))
                .Select(line => line.Split('|')[0].Trim())
                .Where(name => name.Length > 0)
                .ToHashSet(StringComparer.OrdinalIgnoreCase)
            : new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var username in usernames)
            EnsureFriendFile(username);
    }

    public List<string> GetFriends(string username)
    {
        var path = GetFriendFilePath(username);
        return File.Exists(path)
            ? File.ReadLines(path).Select(line => line.Trim()).Where(line => line.Length > 0).ToList()
            : new List<string>();
    }

    public bool AddFriend(string username, string friendUsername)
    {
        if (!usernames.Contains(username) || !usernames.Contains(friendUsername) ||
            username.Equals(friendUsername, StringComparison.OrdinalIgnoreCase))
            return false;

        var friends = GetFriends(username);
        if (friends.Contains(friendUsername, StringComparer.OrdinalIgnoreCase))
            return false;

        File.AppendAllText(GetFriendFilePath(username), friendUsername + Environment.NewLine);
        return true;
    }

    public bool DeleteFriend(string username, string friendUsername)
    {
        if (!usernames.Contains(username))
            return false;

        var friends = GetFriends(username);
        var existing = friends.FirstOrDefault(friend => friend.Equals(friendUsername, StringComparison.OrdinalIgnoreCase));
        if (existing is null)
            return false;

        friends.Remove(existing);
        File.WriteAllLines(GetFriendFilePath(username), friends);
        return true;
    }

    private string GetFriendFilePath(string username)
    {
        // Resolve the canonical name from the credentials list before forming a path.
        var canonicalName = usernames.FirstOrDefault(name => name.Equals(username, StringComparison.OrdinalIgnoreCase));
        if (canonicalName is null)
            throw new ArgumentException("Unknown username.", nameof(username));
        return Path.Combine(friendsDirectory, canonicalName + ".txt");
    }

    private void EnsureFriendFile(string username)
    {
        var path = Path.Combine(friendsDirectory, username + ".txt");
        if (!File.Exists(path))
            File.WriteAllText(path, string.Empty);
    }
}
